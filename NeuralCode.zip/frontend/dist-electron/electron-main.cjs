"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const child_process_1 = require("child_process");
const path = __importStar(require("path"));
const fs = __importStar(require("fs"));
let mainWindow = null;
let pythonProcess = null;
const PYTHON_PORT = 8000;
const isDev = !electron_1.app.isPackaged;
const isWindows = process.platform === "win32";
function getBackendDir() {
    if (isDev) {
        return path.join(__dirname, "..", "..", "backend");
    }
    // In packaged app the backend is placed via extraResources → resources/backend/
    // This avoids asar entirely, so no path guessing needed.
    return path.join(process.resourcesPath, "backend");
}
// Find the bundled server executable (produced by PyInstaller onedir build)
function findBundledExecutable() {
    const backendDir = getBackendDir();
    const candidates = isWindows ? ["server.exe", "server"] : ["server"];
    for (const candidate of candidates) {
        const candidatePath = path.join(backendDir, candidate);
        if (fs.existsSync(candidatePath) && fs.statSync(candidatePath).isFile()) {
            return candidatePath;
        }
    }
    if (!fs.existsSync(backendDir)) {
        return null;
    }
    const recursiveFind = (dir) => {
        try {
            for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
                const entryPath = path.join(dir, entry.name);
                if (entry.isFile() && candidates.includes(entry.name)) {
                    return entryPath;
                }
                if (entry.isDirectory()) {
                    const found = recursiveFind(entryPath);
                    if (found) {
                        return found;
                    }
                }
            }
        }
        catch (_a) {
            // ignore read errors
        }
        return null;
    };
    return recursiveFind(backendDir);
}
// Get Python executable path (fallback when no bundled exe is present)
function getPythonExecutable() {
    const backendDir = getBackendDir();
    const resolveExecutable = (executable) => {
        if (isWindows && !path.isAbsolute(executable) && !executable.includes(path.sep)) {
            return executable;
        }
        if (path.isAbsolute(executable) || executable.includes(path.sep)) {
            return executable;
        }
        try {
            const { execSync } = require("child_process");
            if (isWindows) {
                const result = execSync(`where.exe ${executable}`, {
                    stdio: ["pipe", "pipe", "ignore"],
                })
                    .toString()
                    .split(/\r?\n/)[0]
                    .trim();
                if (result && fs.existsSync(result)) {
                    return result;
                }
            }
            else {
                const result = execSync(`command -v ${executable}`, {
                    stdio: ["pipe", "pipe", "ignore"],
                    shell: true,
                })
                    .toString()
                    .trim();
                if (result) {
                    return result;
                }
            }
        }
        catch (_a) {
            // ignore resolution failures
        }
        return executable;
    };
    const canExecute = (executable, args) => {
        try {
            const { spawnSync } = require("child_process");
            const result = spawnSync(executable, args, {
                stdio: "ignore",
            });
            return !result.error && result.status === 0;
        }
        catch (_a) {
            return false;
        }
    };
    // Try local venv first, then common launchers
    const pythonPaths = [
        path.join(backendDir, ".venv", "Scripts", "python.exe"),
        path.join(backendDir, ".venv", "bin", "python"),
        "python",
        "python3",
        "python.exe",
        "python3.exe",
        "py",
        "py.exe",
    ];
    for (const pythonPath of pythonPaths) {
        const resolvedPath = resolveExecutable(pythonPath);
        const probeArgs = isWindows &&
            (resolvedPath.toLowerCase().endsWith("\\py.exe") ||
                resolvedPath.toLowerCase() === "py" ||
                resolvedPath.toLowerCase() === "py.exe")
            ? ["-3", "--version"]
            : ["--version"];
        if (canExecute(resolvedPath, probeArgs)) {
            return resolvedPath;
        }
    }
    throw new Error("Python not found in PATH");
}
// Start Python backend
function startPythonBackend() {
    return new Promise((resolve, reject) => {
        try {
            const backendDir = getBackendDir();
            // Prefer the bundled executable so the app works without Python installed
            const bundledExe = findBundledExecutable();
            let spawnCmd;
            let spawnArgs;
            if (bundledExe) {
                console.log(`Using bundled server executable: ${bundledExe}`);
                spawnCmd = bundledExe;
                spawnArgs = [];
            }
            else {
                // Fall back to system Python
                const pythonExe = getPythonExecutable();
                const serverScript = path.join(backendDir, "server.py");
                spawnArgs = isWindows &&
                    (pythonExe.toLowerCase().endsWith("\\py.exe") ||
                        pythonExe.toLowerCase() === "py" ||
                        pythonExe.toLowerCase() === "py.exe")
                    ? ["-3", serverScript]
                    : [serverScript];
                console.log(`Starting Python backend: ${pythonExe} ${spawnArgs.join(" ")}`);
                spawnCmd = pythonExe;
            }
            pythonProcess = (0, child_process_1.spawn)(spawnCmd, spawnArgs, {
                cwd: backendDir,
                stdio: ["ignore", "pipe", "pipe"],
                detached: !isWindows,
                windowsHide: true,
            });
            pythonProcess.stdout?.on("data", (data) => {
                console.log(`[Backend] ${data.toString()}`);
            });
            pythonProcess.stderr?.on("data", (data) => {
                console.error(`[Backend Error] ${data.toString()}`);
            });
            pythonProcess.on("error", (err) => {
                console.error("Failed to start backend:", err);
                reject(err);
            });
            // Wait a bit for the backend to start
            setTimeout(() => {
                resolve();
            }, 3000);
        }
        catch (err) {
            reject(err);
        }
    });
}
// Stop Python backend
function stopPythonBackend() {
    if (!pythonProcess || !pythonProcess.pid) {
        return;
    }
    try {
        if (isWindows) {
            const { spawnSync } = require("child_process");
            const result = spawnSync("taskkill", ["/PID", String(pythonProcess.pid), "/T", "/F"], { stdio: "ignore" });
            if (result.error && result.error.code !== "ESRCH") {
                throw result.error;
            }
        }
        else {
            process.kill(-pythonProcess.pid);
        }
    }
    catch (err) {
        // The process may already have exited; avoid noisy shutdown errors.
        if (err.code !== "ESRCH") {
            console.error("Error killing Python process:", err);
        }
    }
    pythonProcess = null;
}
// Create main window
async function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1400,
        height: 900,
        minWidth: 800,
        minHeight: 600,
        webPreferences: {
            preload: path.join(__dirname, "preload.js"),
            nodeIntegration: false,
            contextIsolation: true,
            sandbox: true,
        },
    });
    if (isDev) {
        await mainWindow.loadURL("http://localhost:5000");
        mainWindow.webContents.openDevTools();
    }
    else {
        await mainWindow.loadFile(path.join(__dirname, "..", "dist", "index.html"));
    }
    mainWindow.on("closed", () => {
        mainWindow = null;
    });
}
// IPC Handlers
electron_1.ipcMain.handle("backend-ready", async () => {
    const http = require("http");
    return new Promise((resolve) => {
        const check = () => {
            http
                .get(`http://localhost:${PYTHON_PORT}/health`, (res) => {
                if (res.statusCode === 200) {
                    resolve(true);
                }
                else {
                    setTimeout(check, 500);
                }
            })
                .on("error", () => {
                setTimeout(check, 500);
            });
        };
        check();
    });
});
electron_1.ipcMain.handle("open-file-dialog", async () => {
    if (!mainWindow)
        return null;
    const result = await electron_1.dialog.showOpenDialog(mainWindow, {
        properties: ["openDirectory"],
    });
    return result.canceled ? null : result.filePaths[0];
});
electron_1.ipcMain.handle("open-external-link", (_, url) => {
    electron_1.shell.openExternal(url);
});
electron_1.ipcMain.handle("get-app-version", () => {
    return electron_1.app.getVersion();
});
electron_1.ipcMain.handle("get-app-path", () => {
    return electron_1.app.getAppPath();
});
// App event handlers
electron_1.app.on("ready", async () => {
    try {
        console.log("Starting NeuralCode...");
        await startPythonBackend();
        await createWindow();
        createMenu();
    }
    catch (err) {
        console.error("Failed to start app:", err);
        const message = err instanceof Error ? err.message : String(err);
        electron_1.dialog.showErrorBox("Startup Error", `Failed to start NeuralCode backend.\n\n${message}\n\nPlease reinstall the application.`);
        electron_1.app.quit();
    }
});
electron_1.app.on("window-all-closed", () => {
    stopPythonBackend();
    if (process.platform !== "darwin") {
        electron_1.app.quit();
    }
});
electron_1.app.on("activate", async () => {
    if (mainWindow === null) {
        try {
            await startPythonBackend();
            await createWindow();
        }
        catch (err) {
            console.error("Failed to recreate window:", err);
        }
    }
});
electron_1.app.on("before-quit", () => {
    stopPythonBackend();
});
// Create application menu
function createMenu() {
    const template = [
        {
            label: "File",
            submenu: [
                {
                    label: "Exit",
                    accelerator: "CmdOrCtrl+Q",
                    click: () => {
                        electron_1.app.quit();
                    },
                },
            ],
        },
        {
            label: "Edit",
            submenu: [
                { label: "Undo", accelerator: "CmdOrCtrl+Z", role: "undo" },
                { label: "Redo", accelerator: "CmdOrCtrl+Y", role: "redo" },
                { type: "separator" },
                { label: "Cut", accelerator: "CmdOrCtrl+X", role: "cut" },
                { label: "Copy", accelerator: "CmdOrCtrl+C", role: "copy" },
                { label: "Paste", accelerator: "CmdOrCtrl+V", role: "paste" },
            ],
        },
        {
            label: "View",
            submenu: [
                { label: "Reload", accelerator: "CmdOrCtrl+R", role: "reload" },
                {
                    label: "Toggle DevTools",
                    accelerator: "CmdOrCtrl+Shift+I",
                    role: "toggleDevTools",
                },
            ],
        },
        {
            label: "Help",
            submenu: [
                {
                    label: "About",
                    click: () => {
                        electron_1.dialog.showMessageBox(mainWindow, {
                            type: "info",
                            title: "About NeuralCode",
                            message: `NeuralCode v${electron_1.app.getVersion()}`,
                            detail: "An AI-powered code editor and workspace manager.\n\nBuilt with Electron, React, and Python.",
                        });
                    },
                },
            ],
        },
    ];
    const menu = electron_1.Menu.buildFromTemplate(template);
    electron_1.Menu.setApplicationMenu(menu);
}
// Handle any uncaught exceptions
process.on("uncaughtException", (err) => {
    console.error("Uncaught Exception:", err);
});
