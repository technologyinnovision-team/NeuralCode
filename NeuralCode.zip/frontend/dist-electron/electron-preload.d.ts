declare global {
    interface Window {
        electronAPI: {
            backendReady: () => Promise<boolean>;
            openFileDialog: () => Promise<string | null>;
            openExternalLink: (url: string) => Promise<void>;
            getAppVersion: () => Promise<string>;
            getAppPath: () => Promise<string>;
            onMessage: (channel: string, callback: (event: any, ...args: any[]) => void) => void;
            offMessage: (channel: string, callback: (event: any, ...args: any[]) => void) => void;
            once: (channel: string, callback: (event: any, ...args: any[]) => void) => void;
            platform: string;
            isPackaged: boolean;
        };
    }
}
export {};
