"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
// Preload script to safely expose limited APIs
electron_1.contextBridge.exposeInMainWorld("electronAPI", {
    // Backend communication
    backendReady: () => electron_1.ipcRenderer.invoke("backend-ready"),
    // File dialogs
    openFileDialog: () => electron_1.ipcRenderer.invoke("open-file-dialog"),
    // External links
    openExternalLink: (url) => electron_1.ipcRenderer.invoke("open-external-link", url),
    // App info
    getAppVersion: () => electron_1.ipcRenderer.invoke("get-app-version"),
    getAppPath: () => electron_1.ipcRenderer.invoke("get-app-path"),
    // Listen for events from main process
    onMessage: (channel, callback) => {
        if (["app-ready", "app-error", "workspace-opened"].includes(channel)) {
            electron_1.ipcRenderer.on(channel, callback);
        }
    },
    // Remove listeners
    offMessage: (channel, callback) => {
        electron_1.ipcRenderer.off(channel, callback);
    },
    // One-time listeners
    once: (channel, callback) => {
        if (["app-ready", "app-error", "workspace-opened"].includes(channel)) {
            electron_1.ipcRenderer.once(channel, callback);
        }
    },
    // Platform info
    platform: process.platform,
    isPackaged: !process.env.ELECTRON_IS_DEV,
});
